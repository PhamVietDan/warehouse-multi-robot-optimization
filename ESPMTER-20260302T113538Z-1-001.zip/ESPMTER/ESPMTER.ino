#include <WiFi.h>
#include <esp_now.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include <string.h>

/* =========================
   CONFIG
   ========================= */
#define MAX_ROBOTS 5

static const uint32_t STEP_FLUSH_MS = 25;            // 25ms ~ 40Hz
static const int      STEP_MAX_BEFORE_FLUSH = 6;     // dồn tối đa 6 step rồi in

/* =========================
   PEERS (tối đa 5 robot)
   - Điền MAC thật của ESP1..ESP5
   ========================= */
typedef struct {
  uint8_t id;      // 1..MAX_ROBOTS
  uint8_t mac[6];
} RobotPeer;

RobotPeer peers[] = {
  {1,{0x00, 0x00, 0x00, 0x00, 0x00, 0x00} }, // ESP1 <-- ĐIỀN
  {2,{0x00, 0x00, 0x00, 0x00, 0x00, 0x00} }, // ESP2 (ví dụ)
  {3,{0x00, 0x00, 0x00, 0x00, 0x00, 0x00} }, // ESP3 <-- ĐIỀN
  {4,{0x00, 0x00, 0x00, 0x00, 0x00, 0x00} }, // ESP4 <-- ĐIỀN
  {5,{0x84, 0x1F, 0xE8, 0x69, 0xEF, 0x6C} }, // ESP5 <-- ĐIỀN
};
static const int PEER_N = sizeof(peers) / sizeof(peers[0]);

/* =========================
   ESPNOW PAYLOAD
   ========================= */
typedef struct { char msg[32]; } Message;
Message txMsg;

/* =========================
   RX item -> queue
   (có MAC để học MAC)
   ========================= */
typedef struct {
  uint8_t who;      // 1..MAX_ROBOTS, 0=unknown
  uint8_t mac[6];   // ✅ lưu MAC nguồn
  char msg[32];
} RxLine;

QueueHandle_t rxQueue = NULL;

/* =========================
   STEP AGGREGATION STATE
   ========================= */
typedef struct {
  int  pend;        // pending delta step
  char head;        // heading hiện tại
  int  lastIdx;     // last idx (1..6) nếu slave gửi STEP,H,idx
} StepAgg;

static StepAgg agg[MAX_ROBOTS + 1];  // 0 bỏ, dùng 1..MAX_ROBOTS

/* =========================
   UTIL
   ========================= */
static inline void serial_print_line(const char* s) {
  Serial.write((const uint8_t*)s, strlen(s));
  Serial.write('\n');
}

static inline void print_frame(uint8_t id, const char* payload) {
  char out[128];
  snprintf(out, sizeof(out), "@%u,%s", (unsigned)id, payload);
  serial_print_line(out);
}

static bool mac_is_zero(const uint8_t mac[6]) {
  for (int i = 0; i < 6; i++) if (mac[i] != 0) return false;
  return true;
}

static const uint8_t* mac_by_id(uint8_t id) {
  for (int i = 0; i < PEER_N; i++) {
    if (peers[i].id == id) return peers[i].mac;
  }
  return nullptr;
}

static int who_from_mac(const uint8_t* mac) {
  for (int i = 0; i < PEER_N; i++) {
    if (!mac_is_zero(peers[i].mac) && memcmp(mac, peers[i].mac, 6) == 0) return peers[i].id;
  }
  return 0;
}

static void addPeer(const uint8_t *mac) {
  if (!mac || mac_is_zero(mac)) return;
  if (!esp_now_is_peer_exist(mac)) {
    esp_now_peer_info_t peer = {};
    memcpy(peer.peer_addr, mac, 6);
    peer.channel = 0;
    peer.encrypt = false;
    esp_now_add_peer(&peer);
  }
}

/* =========================
   CALLBACK: TUYỆT ĐỐI KHÔNG Serial.print Ở ĐÂY
   ========================= */
void onReceive(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (len <= 0) return;
  if (len > (int)sizeof(Message)) len = sizeof(Message);

  RxLine it = {};
  memcpy(it.mac, info->src_addr, 6);
  it.who = who_from_mac(info->src_addr);

  int n = len;
  if (n > 31) n = 31;
  memcpy(it.msg, data, n);
  it.msg[n] = '\0';

  if (rxQueue) xQueueSend(rxQueue, &it, 0);
}

/* =========================
   FLUSH STEP PENDING
   ========================= */
static void flushSteps(uint8_t who) {
  if (who == 0 || who > MAX_ROBOTS) return;
  if (agg[who].pend <= 0) return;

  char payload[48];
  snprintf(payload, sizeof(payload), "STEP,%c,%d", agg[who].head, agg[who].pend);
  print_frame(who, payload);

  agg[who].pend = 0;
}

static uint32_t lastFlushMs = 0;
static void flushStepsIfDue() {
  uint32_t now = millis();
  if (now - lastFlushMs >= STEP_FLUSH_MS) {
    for (uint8_t id = 1; id <= MAX_ROBOTS; id++) {
      flushSteps(id);
    }
    lastFlushMs = now;
  }
}

/* =========================
   PARSE STEP:
   nhận "STEP,H" hoặc "STEP,H,k"
   - nếu k <= 6 => coi là idx(1..6) và tính delta từ lastIdx
   - nếu k > 6  => coi là delta count luôn
   ========================= */
static bool parseStepMsg(uint8_t who, const char* s, char &h, int &delta) {
  if (strncmp(s, "STEP,", 5) != 0) return false;
  if (strlen(s) < 6) return false;

  h = s[5];
  if (!(h == 'N' || h == 'E' || h == 'S' || h == 'W')) return false;

  delta = 1;

  const char* p = strchr(s + 5, ','); // dấu phẩy sau heading
  if (!p) return true;               // STEP,H

  int k = atoi(p + 1);
  if (k <= 0) { delta = 1; return true; }

  if (k <= 6) {
    int last = agg[who].lastIdx;
    if (k < last) last = 0;          // reset chu kỳ
    delta = k - last;                // có thể 0 nếu trùng
    agg[who].lastIdx = k;
    return true;
  }

  delta = k;                         // k>6: coi là delta
  return true;
}

/* =========================
   RESET IDX KHI CHỐT 1 LỆNH
   ========================= */
static inline void resetIdx(uint8_t who) {
  if (who == 0 || who > MAX_ROBOTS) return;
  agg[who].lastIdx = 0;
}

static bool isTurnOrDone(const char* s) {
  if (strncmp(s, "DONE", 4) == 0) return true;
  if (strncmp(s, "TURN", 4) == 0) return true;
  return false;
}

static void printPeers() {
  serial_print_line("=== PEERS ===");
  for (int i = 0; i < PEER_N; i++) {
    char buf[96];
    snprintf(buf, sizeof(buf),
      "ESP%u MAC=%02X:%02X:%02X:%02X:%02X:%02X%s",
      peers[i].id,
      peers[i].mac[0], peers[i].mac[1], peers[i].mac[2],
      peers[i].mac[3], peers[i].mac[4], peers[i].mac[5],
      mac_is_zero(peers[i].mac) ? " (EMPTY)" : ""
    );
    serial_print_line(buf);
  }
}

/* =========================
   TX helper: gửi payload tới ESP{id}
   ========================= */
static void send_to_robot(uint8_t id, const char* payload) {
  if (id == 0 || id > MAX_ROBOTS) return;

  const uint8_t* mac = mac_by_id(id);
  if (!mac || mac_is_zero(mac)) {
    char warn[64];
    snprintf(warn, sizeof(warn), "TX_FAIL,ESP%u,NO_MAC", (unsigned)id);
    print_frame(0, warn);
    return;
  }

  strncpy(txMsg.msg, payload, sizeof(txMsg.msg));
  txMsg.msg[sizeof(txMsg.msg) - 1] = '\0';

  esp_now_send(mac, (uint8_t*)&txMsg, sizeof(txMsg));

  char txlog[96];
  snprintf(txlog, sizeof(txlog), "TX,%u,%s", (unsigned)id, payload);
  print_frame(0, txlog);
}

/* =========================
   SETUP / LOOP
   ========================= */
void setup() {
  Serial.setTxBufferSize(2048);
  Serial.begin(115200);
  Serial.setTimeout(10);

  WiFi.mode(WIFI_STA);

  rxQueue = xQueueCreate(240, sizeof(RxLine)); // dư cho 5 robot

  if (esp_now_init() != ESP_OK) {
    serial_print_line("ESP-NOW INIT FAIL");
    while (1) delay(100);
  }

  esp_now_register_recv_cb(onReceive);

  for (int i = 0; i < PEER_N; i++) addPeer(peers[i].mac);

  serial_print_line("ESP MASTER READY");
  serial_print_line("PC->MASTER:  ESP2 F  |  ESP2 L  |  ESP2 SETPOSE,2,9,S");
  serial_print_line("MASTER->PC:  @2,STEP,E,3  /  @2,DONE  /  @2,TURN,L");
  serial_print_line("UNKNOWN MAC: @0,UNK_MAC=AA:BB:..,<msg>");
  printPeers();
}

void loop() {
  /* ========= 1) RX: xử lý queue + gom STEP ========= */
  if (rxQueue) {
    RxLine it;
    while (xQueueReceive(rxQueue, &it, 0) == pdTRUE) {

      flushStepsIfDue();

      // STEP => gom (không in ngay)
      if (it.who != 0) {
        char h; int delta;
        if (parseStepMsg(it.who, it.msg, h, delta)) {
          if (delta <= 0) continue; // trùng idx -> bỏ

          if (agg[it.who].pend == 0) agg[it.who].head = h;

          if (agg[it.who].head != h) {
            flushSteps(it.who);
            agg[it.who].head = h;
          }

          agg[it.who].pend += delta;

          if (agg[it.who].pend >= STEP_MAX_BEFORE_FLUSH) {
            flushSteps(it.who);
          }
          continue;
        }
      }

      // TURN/DONE/... => flush step trước rồi in ngay
      if (it.who != 0) flushSteps(it.who);

      if (it.who == 0) {
        // ✅ in kèm MAC để bạn copy điền peers[]
        char unk[128];
        snprintf(unk, sizeof(unk),
          "UNK_MAC=%02X:%02X:%02X:%02X:%02X:%02X,%s",
          it.mac[0], it.mac[1], it.mac[2], it.mac[3], it.mac[4], it.mac[5],
          it.msg
        );
        print_frame(0, unk);
      } else {
        print_frame(it.who, it.msg);

        if (isTurnOrDone(it.msg)) {
          resetIdx(it.who);
        }
      }
    }
  }

  flushStepsIfDue();

  /* ========= 2) TX: ROUTER LỆNH PC -> SLAVES =========
     Cho phép payload dài: "SETPOSE,2,9,S" hoặc "POS,2,9,S"
   */
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    if (cmd.length() == 0) return;

    int p = cmd.indexOf(' ');
    if (p < 0) return;

    String target  = cmd.substring(0, p);    // ESP1 / ESP2 / ...
    String payload = cmd.substring(p + 1);   // F / L / R / SETPOSE,...
    target.trim();
    payload.trim();

    int id = 0;
    if (target.startsWith("ESP")) id = target.substring(3).toInt();
    if (id <= 0 || id > MAX_ROBOTS) return;

    send_to_robot((uint8_t)id, payload.c_str());
  }
}
